document.getElementById('registerForm').addEventListener('submit', async (event) => {
    event.preventDefault();

    const nombre = document.getElementById('nombre').value;
    const correo = document.getElementById('correo').value;
    const contraseña = document.getElementById('contraseña').value;
    const edad = parseInt(document.getElementById('edad').value);

    try {
        // Verificar si el correo ya existe
        const verificacionCorreo = await fetch('http://localhost:5000/api/auth/verificar-correo', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ correo })
        });

        const resultadoVerificacion = await verificacionCorreo.json();

        if (resultadoVerificacion.existe) {
            alert('Este correo ya está registrado. Por favor, usa otro correo.');
            return;
        }

        // Si el correo no existe, procedemos con el registro
        const response = await fetch('http://localhost:5000/api/auth/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ nombre, correo, contraseña, edad })
        });

        const data = await response.json();

        if (response.ok) {
            alert('Registro exitoso. Ahora puedes iniciar sesión.');
            window.location.href = 'login.html';
        } else {
            alert(data.message || 'Error al registrar usuario');
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Error en la conexión. Inténtalo nuevamente.');
    }
});